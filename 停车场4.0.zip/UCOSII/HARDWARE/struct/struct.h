#include "sys.h"
struct tm{
int h;
int m;
int s;	
};
struct park{
int id;
struct tm time;
int fee;
int free;
int rate;	
};
